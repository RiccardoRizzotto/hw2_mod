<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="/js/gallery.js" defer="true"></script>
    <script src="/js/visualizza_gallery.js" defer="true"> </script>
    <link rel="stylesheet" href="/css/gallery.css">
</head>

<body>
<h1 class = "titolo"> Esplora la nostra Gallery </h1>
<article id="album-view"> 
 <img class="image-collage">
</article>

</body>
</html>