<?php
 
 namespace App\Models;
 use Illuminate\Database\Eloquent\Model;

 class DolomitesImage extends Model
  {
     protected $table = 'dolomites_images';
     protected $primaryKey = "id";
     public $timestamps = false;
  }
?>