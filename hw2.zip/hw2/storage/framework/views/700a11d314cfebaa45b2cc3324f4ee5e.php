<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="/js/profilo.js" defer="true"></script>
    <link rel="stylesheet" href="/css/visualizza_profilo.css">
</head>
<body>
<h1 class = "titolo"> Le tue Prenotazioni </h1>
<article id="album-view">
  <div class="dati"> </div>
</article>

</body>
</html><?php /**PATH C:\xampp\htdocs\hw2\hw2\resources\views/visualizza_profilo.blade.php ENDPATH**/ ?>