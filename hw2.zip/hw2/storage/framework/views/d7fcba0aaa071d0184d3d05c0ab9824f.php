<html>
    <head>
        <link rel='stylesheet' href='css/login.css'>

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Accedi</title>
    </head>
    <body>
  
        <main class="login">
        <section class="main">
            <h5>Per continuare, accedi.</h5>
        

                <?php if(isset($error)): ?> {
                    echo "<p class='error'> $error </p>";
                } <?php endif; ?>
            

            <form name='login' method='post'>
                <?php echo csrf_field(); ?>
                
                <div class="username">
                    <label for='username'>Username</label>
                    <input type='text' name='username' value='<?php echo e(old("username")); ?>' >
                </div>

                <div class="password">
                    <label for='password'>Password</label>
                    <input type='password' name='password' value='<?php echo e(old("password")); ?>'>
                </div>

                <div class="submit-container">
                    <div class="login-btn">
                        <input type='submit' value="ACCEDI">
                    </div>
                </div>

            </form>
            <div class="signup"><h4>Non hai un account?</h4></div>
            <div class="signup-btn-container"><a class="signup-btn" href="register">Iscriviti subito</a></div>
        </section>
        </main>
    </body>
</html><?php /**PATH C:\xampp\htdocs\hw2\hw2\resources\views/login.blade.php ENDPATH**/ ?>